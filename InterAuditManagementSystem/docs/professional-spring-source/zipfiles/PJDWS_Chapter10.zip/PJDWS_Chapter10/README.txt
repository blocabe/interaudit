IMPORTANT:

Chapter 10 of Professional Java Development with Spring described Acegi Security
System for Spring as of revison '0.7-snapshot'. The acegidns app described in the
chapter was also built for that version of Acegi Security.

As such, this archive contains the acegi-security-0.7-SNAPSHOT jar, and the
matching source for acegidns.

Acegi Security has continued to be enhanced in the meantime. It is strongly
suggested that for any future use of Acegi Security you work with the current
1.0.0RC2 (as of 2006-2-15) version, which has many enhancements and fixes.
An up to date acegidns sample for the current version of Acegi Security may
be downloaded from
    http://www.acegisecurity.org

If there is a need to be using a version this old, at a minimum, you should be using 
0.7.1 as 0.7 had a bug in the HTTP Session integration filter which could compromise
security.
