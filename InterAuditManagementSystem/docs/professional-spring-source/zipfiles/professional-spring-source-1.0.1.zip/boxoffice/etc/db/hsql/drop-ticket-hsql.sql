/******************************************
 DROP TABLES FOR TICKET DATABASE for HSQL
******************************************/

DROP TABLE Booking IF EXISTS;
DROP TABLE Genre IF EXISTS;
DROP TABLE Performance IF EXISTS;
DROP TABLE Price_Band IF EXISTS;
DROP TABLE Price_Structure IF EXISTS;
DROP TABLE Purchase IF EXISTS;
DROP TABLE Registered_User IF EXISTS;
DROP TABLE Seat IF EXISTS;
DROP TABLE Seat_Class IF EXISTS;
DROP TABLE Seat_Plan_Seat IF EXISTS;
DROP TABLE Seat_Status IF EXISTS;
DROP TABLE Seating_Plan IF EXISTS;
DROP TABLE Show IF EXISTS;