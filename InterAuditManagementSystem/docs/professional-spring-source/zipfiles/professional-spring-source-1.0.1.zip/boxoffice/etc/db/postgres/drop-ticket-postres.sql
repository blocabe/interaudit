-- drops the table structure from the boxoffice app database (normally called 'spring')
-- tested with PostgreSQL 8.0 or later

DROP TABLE Seat_Plan_Seat;
DROP TABLE Seat_Status;
DROP TABLE Seat;
DROP TABLE Performance;
DROP TABLE Booking;
DROP TABLE Shows;
DROP TABLE Seating_Plan;
DROP TABLE Genre;
DROP TABLE Price_Band;
DROP TABLE Price_Structure;
DROP TABLE Purchase;
DROP TABLE Registered_User;
DROP TABLE Seat_Class;