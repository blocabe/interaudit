Code drop v1.0.1.

This source code for chapter 3 ships with only an Eclipse project definition, there is no
Ant build file. This eclipse project depends on the main 'boxoffice' project, from which
it obtains all the java libraries (such as Spring and related libraries).
