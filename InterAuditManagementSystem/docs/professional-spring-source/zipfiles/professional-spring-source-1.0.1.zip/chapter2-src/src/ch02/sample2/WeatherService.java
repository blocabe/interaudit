package ch02.sample2;

import java.util.Date;

/**
 */
public interface WeatherService {
   Double getHistoricalHigh(Date date);
}
