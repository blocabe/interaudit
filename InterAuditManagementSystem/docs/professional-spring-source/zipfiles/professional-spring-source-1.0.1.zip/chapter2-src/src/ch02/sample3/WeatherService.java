package ch02.sample3;

import java.util.Date;

/**
 */
public interface WeatherService {
   Double getHistoricalHigh(Date date);
}
