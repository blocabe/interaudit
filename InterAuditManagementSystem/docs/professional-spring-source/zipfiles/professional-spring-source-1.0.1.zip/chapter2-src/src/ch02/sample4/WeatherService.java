package ch02.sample4;

import java.util.Date;

/**
 */
public interface WeatherService {
   Double getHistoricalHigh(Date date);
}
