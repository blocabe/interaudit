package ch02.sample5;

/**
 */
public class StaticFactory {
  public static TestBean getTestBeanInstance() {
    return new TestBean();
  }
}
