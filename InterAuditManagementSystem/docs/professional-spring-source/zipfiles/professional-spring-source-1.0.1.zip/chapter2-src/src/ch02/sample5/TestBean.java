package ch02.sample5;

/**
 */
public class TestBean {
  int count = 0;
  public void printCount() {
    System.out.println("Count is: " + count++);
  }
}
