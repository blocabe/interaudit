package ch02.sample6;

import java.util.Date;

/**
 */
public interface WeatherService {
   Double getHistoricalHigh(Date date);
}
