package ch02.sample9;

import java.util.Date;

public class StartEndDatesBean {
  
  Date startDate;
  Date endDate;
  
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }
  public Date getStartDate() {
    return startDate;
  }
  
  public void setEndDate(Date endDate) {
    this.endDate = endDate;
  }
  public Date getEndDate() {
    return endDate;
  }

}
