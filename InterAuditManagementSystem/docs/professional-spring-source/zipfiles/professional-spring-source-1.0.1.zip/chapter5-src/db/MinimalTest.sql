create table mytable (id integer, name varchar(100))
