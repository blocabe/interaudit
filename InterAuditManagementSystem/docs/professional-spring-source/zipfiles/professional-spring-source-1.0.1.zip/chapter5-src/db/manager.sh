java -classpath ../lib/hsqldb.jar:/Users/trisberg/Library/Java/jdbc/ojdbc14.jar org.hsqldb.util.DatabaseManagerSwing
