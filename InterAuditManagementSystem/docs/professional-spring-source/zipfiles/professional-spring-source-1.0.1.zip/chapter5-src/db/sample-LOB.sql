CREATE TABLE Show_Poster(
  id INTEGER PRIMARY KEY NOT NULL,
  first_performance DATE,
  poster_image BLOB,
  Show_id INTEGER);
