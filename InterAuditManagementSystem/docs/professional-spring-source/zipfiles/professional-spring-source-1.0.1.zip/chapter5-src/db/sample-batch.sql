create table Contact_List
  (id integer,
   name varchar(100),
   email varchar(100),
   added date);
