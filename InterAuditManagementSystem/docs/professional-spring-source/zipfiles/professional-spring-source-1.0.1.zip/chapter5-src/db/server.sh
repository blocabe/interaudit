java -classpath ../lib/hsqldb.jar org.hsqldb.Server -database ticket
