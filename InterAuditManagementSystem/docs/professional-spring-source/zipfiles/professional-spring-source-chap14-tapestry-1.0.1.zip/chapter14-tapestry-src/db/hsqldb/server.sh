java -classpath ../../../../lib/hsqldb/hsqldb.jar org.hsqldb.Server -database jpetstore
